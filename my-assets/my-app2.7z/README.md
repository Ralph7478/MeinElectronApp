## Lizenz

Dieses Projekt steht unter der [GPLv3-Lizenz](LICENSE).# MeinElectronApp
